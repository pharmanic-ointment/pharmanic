/* ==========================================================================
   PHARMANIC — SITE SETTINGS
   Fill in the details below and they appear everywhere on the site
   (Contact page, footer, buttons). Anything left empty stays as a
   clearly marked placeholder and the related button is shown disabled.
   ========================================================================== */
window.PHARMANIC_CONFIG = {
  // Phone: international format for the link, nicer text for display
  phone: "",            // e.g. "+995555123456"
  phoneDisplay: "",     // e.g. "+995 555 12 34 56"

  email: "",            // e.g. "info@yourdomain.com"

  // WhatsApp number, digits only with country code, e.g. "995555123456"
  whatsapp: "",

  address: "",          // e.g. "12 Example Street, Tbilisi, Georgia"
  hours: "",            // e.g. "Mon–Fri, 09:00–18:00"

  // Text used to show the Google Map on the Contact page (usually the address).
  // Leave empty to hide the map.
  mapQuery: "",

  social: {
    facebook: "",       // full URL, e.g. "https://facebook.com/yourpage"
    instagram: "",
    linkedin: ""
  },

  // CONTACT FORM — backend still needed.
  // Option A: paste a form-service endpoint (Formspree, Getform, Basin, your own API):
  //   formEndpoint: "https://formspree.io/f/xxxxxxx"
  // Option B: leave empty and set `email` above — the form will open the visitor's
  //   email app with the message pre-filled (no server needed, but less seamless).
  formEndpoint: ""
};
