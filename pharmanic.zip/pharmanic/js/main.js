(function () {
  "use strict";
  var cfg = window.PHARMANIC_CONFIG || {};
  var doc = document;
  doc.documentElement.classList.add("js");

  /* ---------- Mobile navigation ---------- */
  var toggle = doc.querySelector(".menu-toggle");
  var nav = doc.getElementById("site-nav");
  function setMenu(open) {
    if (!toggle || !nav) return;
    toggle.setAttribute("aria-expanded", String(open));
    toggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
    nav.classList.toggle("is-open", open);
  }
  if (toggle && nav) {
    toggle.addEventListener("click", function () { setMenu(toggle.getAttribute("aria-expanded") !== "true"); });
    nav.addEventListener("click", function (e) { if (e.target.closest("a")) setMenu(false); });
    doc.addEventListener("keydown", function (e) { if (e.key === "Escape") setMenu(false); });
    window.addEventListener("resize", function () { if (window.innerWidth > 900) setMenu(false); });
  }

  /* ---------- Header shadow on scroll ---------- */
  var header = doc.querySelector(".site-header");
  function onScroll() { if (header) header.classList.toggle("is-scrolled", window.scrollY > 8); }
  onScroll();
  window.addEventListener("scroll", onScroll, { passive: true });

  /* ---------- Reveal on scroll ---------- */
  var revealEls = doc.querySelectorAll(".reveal");
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add("is-in"); io.unobserve(en.target); } });
    }, { threshold: 0.12, rootMargin: "0px 0px -40px 0px" });
    revealEls.forEach(function (el) { io.observe(el); });
  } else {
    revealEls.forEach(function (el) { el.classList.add("is-in"); });
  }

  /* ---------- Footer year ---------- */
  doc.querySelectorAll("[data-year]").forEach(function (el) { el.textContent = new Date().getFullYear(); });

  /* ---------- Contact details from config.js ---------- */
  function setPending(el, on) {
    el.classList.toggle("is-pending", on);
    if (on) {
      el.removeAttribute("href");
      el.setAttribute("aria-disabled", "true");
      el.addEventListener("click", function (e) { e.preventDefault(); });
    } else {
      el.removeAttribute("aria-disabled");
    }
  }
  function textPending(el, on) { el.classList.toggle("is-pending-text", on); }

  doc.querySelectorAll('[data-cfg="phone"]').forEach(function (el) {
    if (cfg.phone) { el.href = "tel:" + cfg.phone.replace(/\s+/g, ""); el.textContent = cfg.phoneDisplay || cfg.phone; textPending(el, false); }
    else textPending(el, true);
  });
  doc.querySelectorAll('[data-cfg="email"]').forEach(function (el) {
    if (cfg.email) { el.href = "mailto:" + cfg.email; el.textContent = cfg.email; textPending(el, false); }
    else textPending(el, true);
  });
  doc.querySelectorAll('[data-cfg="address"]').forEach(function (el) {
    if (cfg.address) { el.textContent = cfg.address; textPending(el, false); } else textPending(el, true);
  });
  doc.querySelectorAll('[data-cfg="hours"]').forEach(function (el) {
    if (cfg.hours) { el.textContent = cfg.hours; textPending(el, false); } else textPending(el, true);
  });
  doc.querySelectorAll('[data-cfg="whatsapp"]').forEach(function (el) {
    var n = (cfg.whatsapp || "").replace(/\D/g, "");
    if (n) { el.href = "https://wa.me/" + n; el.target = "_blank"; el.rel = "noopener"; setPending(el, false); }
    else { setPending(el, true); el.title = "WhatsApp number not added yet"; }
  });
  ["facebook", "instagram", "linkedin"].forEach(function (k) {
    doc.querySelectorAll('[data-cfg="' + k + '"]').forEach(function (el) {
      var url = cfg.social && cfg.social[k];
      if (url) { el.href = url; el.target = "_blank"; el.rel = "noopener noreferrer"; setPending(el, false); }
      else { setPending(el, true); el.title = k.charAt(0).toUpperCase() + k.slice(1) + " link not added yet"; }
    });
  });
  var mapWrap = doc.getElementById("map-wrap");
  if (mapWrap && cfg.mapQuery) {
    var f = doc.createElement("iframe");
    f.title = "Pharmanic location on Google Maps";
    f.loading = "lazy";
    f.referrerPolicy = "no-referrer-when-downgrade";
    f.src = "https://www.google.com/maps?q=" + encodeURIComponent(cfg.mapQuery) + "&output=embed";
    mapWrap.appendChild(f);
    mapWrap.hidden = false;
  }

  /* ---------- Product filter (products page) ---------- */
  var chips = doc.querySelectorAll(".chip[data-filter]");
  var details = doc.querySelectorAll(".detail[data-cat]");
  if (chips.length) {
    chips.forEach(function (chip) {
      chip.addEventListener("click", function () {
        var f = chip.getAttribute("data-filter");
        chips.forEach(function (c) { c.setAttribute("aria-pressed", String(c === chip)); });
        details.forEach(function (d) { d.hidden = !(f === "all" || d.getAttribute("data-cat") === f); });
      });
    });
  }

  /* ---------- Contact form ---------- */
  var form = doc.getElementById("contact-form");
  if (form) {
    var params = new URLSearchParams(window.location.search);
    var pre = params.get("product");
    var sel = form.querySelector("#product");
    if (pre && sel) { for (var i = 0; i < sel.options.length; i++) { if (sel.options[i].value === pre) sel.selectedIndex = i; } }

    var status = doc.getElementById("form-status");
    function say(kind, msg) { status.className = "form-status is-" + kind; status.textContent = msg; status.focus(); }
    function validate() {
      var ok = true;
      form.querySelectorAll("[required]").forEach(function (inp) {
        var wrap = inp.closest(".field"); var err = wrap.querySelector(".err");
        var bad = !inp.value.trim() || (inp.type === "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(inp.value));
        wrap.classList.toggle("has-error", bad);
        if (err) err.textContent = bad ? (inp.type === "email" && inp.value ? "Please enter a valid email address." : "This field is required.") : "";
        if (bad) ok = false;
      });
      return ok;
    }
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      if (form.querySelector(".hp input").value) return; // honeypot
      if (!validate()) { form.querySelector(".has-error input, .has-error textarea, .has-error select").focus(); return; }
      var data = {};
      new FormData(form).forEach(function (v, k) { if (k !== "website") data[k] = v; });
      var btn = form.querySelector('button[type="submit"]');

      if (cfg.formEndpoint) {
        btn.disabled = true;
        fetch(cfg.formEndpoint, { method: "POST", headers: { "Content-Type": "application/json", "Accept": "application/json" }, body: JSON.stringify(data) })
          .then(function (r) { if (!r.ok) throw new Error(); say("ok", "Thank you — your message has been sent. We will get back to you shortly."); form.reset(); })
          .catch(function () { say("error", "Sorry, something went wrong while sending. Please try again or contact us directly."); })
          .then(function () { btn.disabled = false; });
      } else if (cfg.email) {
        var body = "Name: " + data.name + "\nContact: " + data.contact + "\nI am a: " + data.role + "\nProduct: " + data.product + "\n\n" + data.message;
        window.location.href = "mailto:" + cfg.email + "?subject=" + encodeURIComponent("Website enquiry from " + data.name) + "&body=" + encodeURIComponent(body);
        say("ok", "Your email app should now open with the message ready to send.");
      } else {
        say("info", "Thank you! The message form is not connected to an email service yet (setup pending), so nothing was sent. Please reach us by phone or email in the meantime.");
      }
    });
  }
})();
